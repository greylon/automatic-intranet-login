// CredentialStorage.cpp : Defines the exported functions for the DLL application.
//

#include "stdafx.h"
#include "Utils.h"
#include "CNGCrypt.h"
#include "RegistryHelper.h"
#include "CredentialStorage.h"

#define CREDENTIAL_ROOT_REGISTRY_PATH std::wstring(L"SOFTWARE\\Refugee Action")
#define CREDENTIAL_REGISTRY_PATH (CREDENTIAL_ROOT_REGISTRY_PATH + L"\\AutoIntranetLogin")
#define USER_NAME_ATTR L"Username"
#define USER_PASS_ATTR L"Password"
#define RUNONCE_REGISTRY_PATH L"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\RunOnce"
#define DESCRIPTION_ATTR L"AutomaticIntranetLogon"

#define CRYPT_KEY L"34080497d399"

CREDENTIALSTORAGE_API bool CLIB_StoreCredentials(const std::wstring& i_userName, const std::wstring& i_password, std::wstring& o_error)
{
   ByteArray blobUserName = utils::String2ByteArray(CStringW(i_userName.c_str()));
   ByteArray blobUserPass = utils::String2ByteArray(CStringW(i_password.c_str()));
   ByteArray blobEncodedUserName;
   ByteArray blobEncodedUserPass;
  
   try
   {
      // ISSUE: Tried to use utils::GetMACAddressString() call for salt generating, but it looks does not work for my WiFi connection,
      //   this call generates empty string for CP provider that is storing credentials, it looks like this is because. Then this call will return 
      //   good MAC address when net connection is established
      CStringW userNameKey = CStringW(CRYPT_KEY); //utils::GetMACAddressString(); does not work for CP call
      CStringW userPassKey = userNameKey;

      CCNGCrypt crypter;
      crypter.CryptBuffer(true, userNameKey, blobUserName, blobEncodedUserName);
      crypter.CryptBuffer(true, userPassKey.MakeReverse(), blobUserPass, blobEncodedUserPass);

      CRegistryHelper m_registry;
      m_registry.open(HKEY_LOCAL_MACHINE, CREDENTIAL_REGISTRY_PATH, true);
      
      m_registry.write_value(USER_NAME_ATTR, blobEncodedUserName);
      m_registry.write_value(USER_PASS_ATTR, blobEncodedUserPass);
   }
   catch (const utils::CStorageException& e)
   {
      CStringW msg;
      msg.Format(L"%s(%s)", e.GetMessage().GetString(), e.GetSystemError().GetString());
      o_error = msg.GetString();
      return false;
   }

   return true;
}

CREDENTIALSTORAGE_API bool CLIB_LoadCredentials(std::wstring& o_userName, std::wstring& o_password, std::wstring& o_error)
{
   ByteArray blobEncodedUserName;
   ByteArray blobEncodedUserPass;
   ByteArray blobDecodedUserName;
   ByteArray blobDecodedUserPass;

   try
   {
      CRegistryHelper m_registry;
      m_registry.open(HKEY_LOCAL_MACHINE, CREDENTIAL_REGISTRY_PATH, false);
      m_registry.read_value(USER_NAME_ATTR, blobEncodedUserName);
      m_registry.read_value(USER_PASS_ATTR, blobEncodedUserPass);

      // ISSUE: Tried to use utils::GetMACAddressString() call for salt generating, but it looks does not work for my WiFi connection,
      //   this call generates empty string for CP provider that is storing credentials, it looks like this is because. Then this call will return 
      //   good MAC address when net connection is established
      CStringW userNameKey = CStringW(CRYPT_KEY); //utils::GetMACAddressString(); does not work for CP call
      CStringW userPassKey = userNameKey;

      CCNGCrypt crypter;
      crypter.CryptBuffer(false, userNameKey, blobEncodedUserName, blobDecodedUserName);
      crypter.CryptBuffer(false, userPassKey.MakeReverse(), blobEncodedUserPass, blobDecodedUserPass);

      CStringW userName = utils::ByteArray2String(blobDecodedUserName);
      CStringW userPass = utils::ByteArray2String(blobDecodedUserPass);

      o_userName = userName.GetString();
      o_password = userPass.GetString();
   }
   catch (const utils::CStorageException& e)
   {
      CStringW msg;
      msg.Format(L"%s(%s)", e.GetMessage().GetString(), e.GetSystemError().GetString());
      o_error = msg.GetString();
      return false;
   }

   return true;
}

//////////////////////////////////////////////////////////////////////////
CREDENTIALSTORAGE_API bool CLIB_ClearCredentials(std::wstring& o_error)
{
   try
   {
      CRegistryHelper::delete_key(HKEY_LOCAL_MACHINE, CREDENTIAL_ROOT_REGISTRY_PATH);
   }
   catch (const utils::CStorageException& e)
   {
      CStringW msg;
      msg.Format(L"%s(%s)", e.GetMessage().GetString(), e.GetSystemError().GetString());
      o_error = msg.GetString();
      return false;
   }

   return true;
}

//////////////////////////////////////////////////////////////////////////
CREDENTIALSTORAGE_API bool CLIB_RunAtOnce ( const std::wstring& i_appName, std::wstring& o_error )
{
   try
   {
      CRegistryHelper m_registry;
      m_registry.open(HKEY_LOCAL_MACHINE, RUNONCE_REGISTRY_PATH, true);
      m_registry.write_value(DESCRIPTION_ATTR, i_appName);
   }
   catch (const utils::CStorageException& e)
   {
      CStringW msg;
      msg.Format(L"%s(%s)", e.GetMessage().GetString(), e.GetSystemError().GetString());
      o_error = msg.GetString();
      return false;
   }

   return true;
}

///////////////////////////////////////////////
CREDENTIALSTORAGE_API void CLIB_LogMessage ( const wchar_t* i_fmt, ...)
{
   wchar_t szMessageBuf[512] = {0};	/* Hope this is big enough */

   SYSTEMTIME stm;
   GetLocalTime(&stm);

   va_list pArg;
   va_start(pArg, i_fmt);
   _vsnwprintf_s(szMessageBuf, _TRUNCATE, i_fmt, pArg);
   va_end(pArg);

   FILE *filea = NULL; 
   _wfopen_s(&filea, L"C:\\cplog.txt", L"a+");
   fwprintf_s(filea, L"%02d-%02d-%04d %02d:%02d:%02d %s\n", 
      stm.wMonth, stm.wDay, stm.wYear, stm.wHour, stm.wMinute, stm.wSecond, szMessageBuf);
   fclose(filea);

   ::OutputDebugStringW(szMessageBuf);
}