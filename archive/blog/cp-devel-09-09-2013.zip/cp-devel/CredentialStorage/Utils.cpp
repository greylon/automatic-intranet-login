#include "StdAfx.h"
#include <nb30.h>
#include <assert.h>
#include "Utils.h"

namespace
{
   typedef struct _ASTAT_
   {
      ADAPTER_STATUS adapt;
      NAME_BUFFER NameBuff [30];
   }
   ASTAT, * PASTAT;

   std::vector<UCHAR> enum_lan_adapters()
   {
      std::vector<UCHAR> lans;

      NCB Ncb;
      UCHAR uRetCode;

      LANA_ENUM lana_enum = {0};

      memset( &Ncb, 0, sizeof (Ncb) );
      Ncb.ncb_command = NCBENUM;
      Ncb.ncb_buffer = (PUCHAR) &lana_enum;
      Ncb.ncb_length = sizeof(lana_enum);

      uRetCode = Netbios( &Ncb );
      if ( 0 == uRetCode )
      {
         std::multiset<UCHAR> sorted_adapt;
         std::copy(lana_enum.lana, lana_enum.lana + lana_enum.length, std::inserter(sorted_adapt, sorted_adapt.begin()));
         std::copy(sorted_adapt.begin(), sorted_adapt.end(), std::back_inserter(lans));
      }

/*
      Debug << "INSTALLER CRYPTO HELPER --> Found " 
         << (long) lans.size() 
         << " lan adapters (ret code: " << uRetCode << ") --> Adapters "
         << converter::BinaryToString(btstring(lana_enum.lana, lana_enum.length), converter::CTYPE_HEX)
         << "\n"; 
*/

      return lans;
   }

   ByteArray get_MAC_address(BYTE i_nAdapterNum)
   {
      NCB Ncb;
      UCHAR uRetCode;

      memset( &Ncb, 0, sizeof(Ncb) );
      Ncb.ncb_command = NCBRESET;
      Ncb.ncb_lana_num = i_nAdapterNum;

      uRetCode = Netbios( &Ncb );

      memset( &Ncb, 0, sizeof (Ncb) );
      Ncb.ncb_command = NCBASTAT;
      Ncb.ncb_lana_num = i_nAdapterNum;

      ASTAT Adapter;
      std::string callname("* ");
      memcpy( Ncb.ncb_callname, callname.c_str(), callname.size() );
      Ncb.ncb_buffer = (PUCHAR) &Adapter;
      Ncb.ncb_length = sizeof(Adapter);

      uRetCode = Netbios( &Ncb );
      if ( uRetCode == 0 )
      {
         /*
         wchar_t NetName[50];
         swprintf(NetName, L"%02x%02x%02x%02x%02x%02x",
         Adapter.adapt.adapter_address[0],
         Adapter.adapt.adapter_address[1],
         Adapter.adapt.adapter_address[2],
         Adapter.adapt.adapter_address[3],
         Adapter.adapt.adapter_address[4],
         Adapter.adapt.adapter_address[5] );*/
         UCHAR (&adapter_address)[6] = Adapter.adapt.adapter_address;
         return ByteArray(adapter_address, adapter_address + _countof(adapter_address));
      }

      return ByteArray();
   }

}

namespace utils
{
   ByteArray FindMACAddress()
   {
      std::vector<UCHAR> lans = enum_lan_adapters();
      std::vector<UCHAR>::iterator iter = lans.begin();
      for (; iter != lans.end(); ++iter)
      {
         ByteArray address = get_MAC_address(*iter);
         if (!address.empty()) 
         {
            return address;
         }
      }
      return ByteArray();
   }

   CStringW GetMACAddressString()
   {
      CStringW macAddressStr;
      ByteArray macAddress = FindMACAddress();
      for (int i = 0; i < macAddress.size(); ++i)
      {
         macAddressStr.AppendFormat(L"%02x", macAddress[i]);
      }
      return macAddressStr;
   }

   ByteArray String2ByteArray( const CStringW& i_str )
   {
      ByteArray blob;

      const BYTE* buf = (const BYTE*) i_str.GetString();
      const int buf_len = (i_str.GetLength() + 1) * sizeof(WCHAR);
      
      std::copy(buf, buf+buf_len, std::back_inserter(blob));
      return blob;
   }

   CStringW ByteArray2String( const ByteArray& i_blob )
   {
      if (i_blob.empty() || i_blob.size()%sizeof(WCHAR) != 0)
      {
         return CStringW();

      }
      return CStringW((const wchar_t*)&i_blob[0], i_blob.size()/sizeof(WCHAR));
   }

   CStringW GetSystemMessageW( DWORD iCode )
   {
      std::wstring message;
      WCHAR* messageBuffer;

      if( FormatMessageW( FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM | FORMAT_MESSAGE_IGNORE_INSERTS, NULL, iCode, MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT), (LPWSTR)&messageBuffer, 0, NULL ) )
      {
         message = messageBuffer;
         LocalFree( messageBuffer );
      }

      while( !message.empty() && ( wcschr( L"\r\n" , message[message.size() - 1] ) != NULL ) )
      {
         message.resize( message.size() - 1 );
      }

      return message.c_str();
   }

   CStringA GetSystemMessageA( DWORD iCode )
   {
      CStringW msg = GetSystemMessageW(iCode);
      return CStringA(msg);
   }

   //////////////////////////////////////////////////////////////////////////
   CStorageException::CStorageException(const CStringW& i_message, DWORD i_errorCode)
   : m_message(i_message)
   , m_systemError(GetSystemMessageW(i_errorCode))
   {

   }

}